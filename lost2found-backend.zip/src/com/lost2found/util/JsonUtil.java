package com.lost2found.util;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Minimal but complete JSON reader/writer covering everything this
 * app's RPC payloads need: objects (as LinkedHashMap, order kept),
 * arrays (as ArrayList), strings, numbers (as Double), booleans and
 * null. Written from scratch so the project has zero external
 * dependencies - no Gson/Jackson jar to fetch.
 */
public final class JsonUtil {

    private JsonUtil() {
    }

    // ---------------------------------------------------------------
    // Parsing
    // ---------------------------------------------------------------

    public static Object parse(String json) {
        if (json == null) return null;
        Parser p = new Parser(json);
        p.skipWhitespace();
        Object value = p.parseValue();
        return value;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> parseObject(String json) {
        Object value = parse(json);
        if (value instanceof Map) return (Map<String, Object>) value;
        return new LinkedHashMap<>();
    }

    private static class Parser {
        private final String s;
        private int i;

        Parser(String s) {
            this.s = s;
            this.i = 0;
        }

        void skipWhitespace() {
            while (i < s.length() && Character.isWhitespace(s.charAt(i))) i++;
        }

        Object parseValue() {
            skipWhitespace();
            if (i >= s.length()) return null;
            char c = s.charAt(i);
            if (c == '{') return parseObjectValue();
            if (c == '[') return parseArrayValue();
            if (c == '"') return parseStringValue();
            if (c == 't' || c == 'f') return parseBooleanValue();
            if (c == 'n') {
                i += 4; // "null"
                return null;
            }
            return parseNumberValue();
        }

        Map<String, Object> parseObjectValue() {
            Map<String, Object> map = new LinkedHashMap<>();
            i++; // consume '{'
            skipWhitespace();
            if (i < s.length() && s.charAt(i) == '}') {
                i++;
                return map;
            }
            while (i < s.length()) {
                skipWhitespace();
                String key = parseStringValue();
                skipWhitespace();
                if (i < s.length() && s.charAt(i) == ':') i++;
                Object value = parseValue();
                map.put(key, value);
                skipWhitespace();
                if (i < s.length() && s.charAt(i) == ',') {
                    i++;
                    continue;
                }
                if (i < s.length() && s.charAt(i) == '}') {
                    i++;
                    break;
                }
                break;
            }
            return map;
        }

        List<Object> parseArrayValue() {
            List<Object> list = new ArrayList<>();
            i++; // consume '['
            skipWhitespace();
            if (i < s.length() && s.charAt(i) == ']') {
                i++;
                return list;
            }
            while (i < s.length()) {
                Object value = parseValue();
                list.add(value);
                skipWhitespace();
                if (i < s.length() && s.charAt(i) == ',') {
                    i++;
                    continue;
                }
                if (i < s.length() && s.charAt(i) == ']') {
                    i++;
                    break;
                }
                break;
            }
            return list;
        }

        String parseStringValue() {
            skipWhitespace();
            if (i >= s.length() || s.charAt(i) != '"') return "";
            i++; // opening quote
            StringBuilder sb = new StringBuilder();
            while (i < s.length() && s.charAt(i) != '"') {
                char c = s.charAt(i);
                if (c == '\\' && i + 1 < s.length()) {
                    char next = s.charAt(i + 1);
                    switch (next) {
                        case 'n': sb.append('\n'); break;
                        case 't': sb.append('\t'); break;
                        case 'r': sb.append('\r'); break;
                        case '"': sb.append('"'); break;
                        case '\\': sb.append('\\'); break;
                        case '/': sb.append('/'); break;
                        case 'u':
                            if (i + 5 < s.length()) {
                                String hex = s.substring(i + 2, i + 6);
                                sb.append((char) Integer.parseInt(hex, 16));
                                i += 4;
                            }
                            break;
                        default: sb.append(next);
                    }
                    i += 2;
                } else {
                    sb.append(c);
                    i++;
                }
            }
            i++; // closing quote
            return sb.toString();
        }

        Boolean parseBooleanValue() {
            if (s.startsWith("true", i)) {
                i += 4;
                return Boolean.TRUE;
            }
            i += 5; // "false"
            return Boolean.FALSE;
        }

        Double parseNumberValue() {
            int start = i;
            while (i < s.length() && "-+.0123456789eE".indexOf(s.charAt(i)) >= 0) i++;
            String num = s.substring(start, i);
            try {
                return Double.parseDouble(num);
            } catch (NumberFormatException e) {
                return 0.0;
            }
        }
    }

    // ---------------------------------------------------------------
    // Writing
    // ---------------------------------------------------------------

    public static String stringify(Object value) {
        StringBuilder sb = new StringBuilder();
        write(value, sb);
        return sb.toString();
    }

    @SuppressWarnings("unchecked")
    private static void write(Object value, StringBuilder sb) {
        if (value == null) {
            sb.append("null");
        } else if (value instanceof String) {
            writeString((String) value, sb);
        } else if (value instanceof Map) {
            sb.append("{");
            boolean first = true;
            for (Map.Entry<String, Object> e : ((Map<String, Object>) value).entrySet()) {
                if (!first) sb.append(",");
                first = false;
                writeString(e.getKey(), sb);
                sb.append(":");
                write(e.getValue(), sb);
            }
            sb.append("}");
        } else if (value instanceof List) {
            sb.append("[");
            boolean first = true;
            for (Object item : (List<Object>) value) {
                if (!first) sb.append(",");
                first = false;
                write(item, sb);
            }
            sb.append("]");
        } else if (value instanceof Boolean) {
            sb.append(value.toString());
        } else if (value instanceof Number) {
            double d = ((Number) value).doubleValue();
            if (d == Math.floor(d) && !Double.isInfinite(d)) {
                sb.append((long) d);
            } else {
                sb.append(d);
            }
        } else {
            writeString(value.toString(), sb);
        }
    }

    private static void writeString(String s, StringBuilder sb) {
        sb.append('"');
        for (int i = 0; i < s.length(); i++) {
            char c = s.charAt(i);
            switch (c) {
                case '"': sb.append("\\\""); break;
                case '\\': sb.append("\\\\"); break;
                case '\n': sb.append("\\n"); break;
                case '\r': sb.append("\\r"); break;
                case '\t': sb.append("\\t"); break;
                default:
                    if (c < 0x20) {
                        sb.append(String.format("\\u%04x", (int) c));
                    } else {
                        sb.append(c);
                    }
            }
        }
        sb.append('"');
    }

    // ---------------------------------------------------------------
    // Convenience readers for pulling typed values out of a parsed
    // payload map without a wall of casts at every call site.
    // ---------------------------------------------------------------

    public static String str(Map<String, Object> map, String key) {
        if (map == null) return null;
        Object v = map.get(key);
        return v == null ? null : String.valueOf(v);
    }

    public static String str(Map<String, Object> map, String key, String fallback) {
        String v = str(map, key);
        return (v == null || v.isEmpty()) ? fallback : v;
    }

    public static double num(Map<String, Object> map, String key, double fallback) {
        if (map == null) return fallback;
        Object v = map.get(key);
        if (v instanceof Number) return ((Number) v).doubleValue();
        if (v instanceof String) {
            try {
                return Double.parseDouble((String) v);
            } catch (NumberFormatException e) {
                return fallback;
            }
        }
        return fallback;
    }

    @SuppressWarnings("unchecked")
    public static Map<String, Object> obj(Map<String, Object> map, String key) {
        if (map == null) return new LinkedHashMap<>();
        Object v = map.get(key);
        if (v instanceof Map) return (Map<String, Object>) v;
        return new LinkedHashMap<>();
    }
}
