package com.lost2found.util;

import java.security.SecureRandom;
import java.util.UUID;

public final class IdUtil {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final String ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"; // no 0/O/1/I

    private IdUtil() {
    }

    public static String newToken() {
        return UUID.randomUUID().toString().replace("-", "");
    }

    public static String newInternalId() {
        return UUID.randomUUID().toString();
    }

    /** e.g. "L2F-4KQ2MZ" - the code students share with each other. */
    public static String newItemCode() {
        StringBuilder sb = new StringBuilder("L2F-");
        for (int i = 0; i < 6; i++) {
            sb.append(ALPHABET.charAt(RANDOM.nextInt(ALPHABET.length())));
        }
        return sb.toString();
    }

    public static String newSixDigitOtp() {
        int code = 100000 + RANDOM.nextInt(900000);
        return String.valueOf(code);
    }

    public static String maskEmail(String email) {
        if (email == null || !email.contains("@")) return email;
        String[] parts = email.split("@", 2);
        String local = parts[0];
        String maskedLocal = local.length() <= 2
                ? local.charAt(0) + "*"
                : local.charAt(0) + repeat("*", local.length() - 2) + local.charAt(local.length() - 1);
        return maskedLocal + "@" + parts[1];
    }

    private static String repeat(String s, int times) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < times; i++) sb.append(s);
        return sb.toString();
    }
}
