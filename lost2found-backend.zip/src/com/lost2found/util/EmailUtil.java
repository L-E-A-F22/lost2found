package com.lost2found.util;

import javax.net.ssl.SSLSocket;
import javax.net.ssl.SSLSocketFactory;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

/**
 * Minimal SMTPS client (talks directly to a raw SSL socket) so this
 * project needs zero external jars for email. Supports AUTH LOGIN,
 * which is all Gmail's SMTP needs.
 */
public final class EmailUtil {

    private EmailUtil() {
    }

    public static void sendEmail(SmtpConfig config, String toEmail,
                                  String subject, String body) throws IOException {
        SSLSocketFactory factory = (SSLSocketFactory) SSLSocketFactory.getDefault();

        // Connect through a plain Socket first with an explicit
        // connect timeout, then layer SSL on top. SSLSocketFactory's
        // own createSocket(host, port) has NO connect timeout and can
        // hang forever if the network silently drops packets (e.g. a
        // firewalled/blocked host) - that would tie up a server
        // thread indefinitely, so we avoid it deliberately.
        try (Socket plain = new Socket()) {
            plain.connect(new InetSocketAddress(config.host, config.port), 8000);

            try (SSLSocket socket = (SSLSocket) factory.createSocket(plain, config.host, config.port, true)) {
                socket.setSoTimeout(15000);

            BufferedReader in = new BufferedReader(
                    new InputStreamReader(socket.getInputStream(), StandardCharsets.UTF_8));
            PrintWriter out = new PrintWriter(socket.getOutputStream(), true);

            readResponse(in);
            send(out, in, "EHLO localhost");
            send(out, in, "AUTH LOGIN");
            send(out, in, base64(config.username));
            send(out, in, base64(config.password));
            send(out, in, "MAIL FROM:<" + config.username + ">");
            send(out, in, "RCPT TO:<" + toEmail + ">");
            send(out, in, "DATA");

            String message =
                    "From: Lost2Found <" + config.username + ">\r\n"
                            + "To: " + toEmail + "\r\n"
                            + "Subject: " + subject + "\r\n"
                            + "MIME-Version: 1.0\r\n"
                            + "Content-Type: text/plain; charset=UTF-8\r\n"
                            + "\r\n"
                            + body + "\r\n"
                            + ".";
                send(out, in, message);
                send(out, in, "QUIT");
            }
        }
    }

    public static void sendOtpEmail(SmtpConfig config, String toEmail, String otpCode) throws IOException {
        String subject = "Your Lost2Found verification code";
        String body = "Your verification code is: " + otpCode
                + "\n\nThis code expires in 10 minutes. If you didn't request this, "
                + "you can safely ignore this email.";
        sendEmail(config, toEmail, subject, body);
    }

    private static String base64(String s) {
        return Base64.getEncoder().encodeToString(s.getBytes(StandardCharsets.UTF_8));
    }

    private static void send(PrintWriter out, BufferedReader in, String command) throws IOException {
        out.print(command + "\r\n");
        out.flush();
        String response = readResponse(in);
        int code = response.length() >= 3 ? parseCode(response) : 0;
        if (code >= 400) {
            throw new IOException("SMTP server rejected command. Response: " + response);
        }
    }

    private static int parseCode(String response) {
        try {
            return Integer.parseInt(response.substring(0, 3));
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static String readResponse(BufferedReader in) throws IOException {
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = in.readLine()) != null) {
            sb.append(line).append("\n");
            if (line.length() >= 4 && line.charAt(3) == ' ') {
                break;
            }
        }
        return sb.toString();
    }

    /**
     * For Gmail: host="smtp.gmail.com", port=465, username=your Gmail
     * address, password= a 16-character "App Password" from
     * https://myaccount.google.com/apppasswords (requires 2FA - do
     * NOT use your normal Gmail login password here).
     */
    public static class SmtpConfig {
        public final String host;
        public final int port;
        public final String username;
        public final String password;

        public SmtpConfig(String host, int port, String username, String password) {
            this.host = host;
            this.port = port;
            this.username = username;
            this.password = password;
        }
    }
}
