package com.lost2found.exception;

/**
 * Thrown by any service method when a request can't be completed for
 * a reason the caller should see (bad input, not found, not allowed,
 * wrong credentials, expired session, etc). The RPC dispatcher
 * catches this centrally and turns it into {"ok":false,"error":...}
 * without a stack trace ever reaching the client.
 */
public class ApiException extends Exception {
    public ApiException(String message) {
        super(message);
    }
}
