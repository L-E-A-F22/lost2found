package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.User;
import com.lost2found.util.PasswordUtil;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.regex.Pattern;

/**
 * Manages all registered users.
 *
 * Data structures:
 *  - ConcurrentHashMap<username, User>  primary store, thread-safe
 *  - ConcurrentHashMap<email, username> secondary index for email lookups
 *  - ConcurrentHashMap<userId, username> secondary index for id lookups
 */
public class UserService {

    private static final Pattern USERNAME_PATTERN = Pattern.compile("^[A-Za-z0-9_]{3,20}$");
    private static final Pattern PASSWORD_PATTERN =
            Pattern.compile("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");

    private final Map<String, User> usersByUsername = new ConcurrentHashMap<>();
    private final Map<String, String> usernameByEmail = new ConcurrentHashMap<>();
    private final Map<String, String> usernameByUserId = new ConcurrentHashMap<>();

    public boolean isUsernameAvailable(String username) {
        if (username == null) return false;
        String key = username.trim().toLowerCase();
        return USERNAME_PATTERN.matcher(username.trim()).matches() && !usersByUsername.containsKey(key);
    }

    public String usernameUnavailableReason(String username) {
        if (username == null || username.trim().isEmpty()) return "Enter a username.";
        if (!USERNAME_PATTERN.matcher(username.trim()).matches()) {
            return "3\u201320 letters, numbers or underscores only.";
        }
        if (usersByUsername.containsKey(username.trim().toLowerCase())) {
            return "That username is already taken.";
        }
        return null;
    }

    public User register(String displayName, String username, String email, String phone,
                          String password, String confirmPassword) throws ApiException {

        if (displayName == null || displayName.trim().isEmpty()) {
            throw new ApiException("Enter your full name.");
        }
        String reason = usernameUnavailableReason(username);
        if (reason != null) {
            throw new ApiException(reason);
        }
        if (email == null || !email.contains("@")) {
            throw new ApiException("Enter a valid email address.");
        }
        if (phone == null || phone.trim().isEmpty()) {
            throw new ApiException("Enter a phone number.");
        }
        if (password == null || !PASSWORD_PATTERN.matcher(password).matches()) {
            throw new ApiException("Password needs at least 8 characters, with upper case, lower case and a number.");
        }
        if (!password.equals(confirmPassword)) {
            throw new ApiException("Passwords do not match.");
        }

        String normalizedUsername = username.trim().toLowerCase();
        String normalizedEmail = email.trim().toLowerCase();

        if (usernameByEmail.containsKey(normalizedEmail)) {
            throw new ApiException("An account with that email already exists.");
        }

        String salt = PasswordUtil.generateSalt();
        String hash = PasswordUtil.hash(password, salt);

        User user = new User(username.trim(), displayName.trim(), normalizedEmail, phone.trim(), hash, salt);

        usersByUsername.put(normalizedUsername, user);
        usernameByEmail.put(normalizedEmail, normalizedUsername);
        usernameByUserId.put(user.getUserId(), normalizedUsername);

        return user;
    }

    public User login(String usernameOrEmail, String password) throws ApiException {
        User user = findByUsernameOrEmail(usernameOrEmail);
        if (user == null || !PasswordUtil.verify(password, user.getPasswordSalt(), user.getPasswordHash())) {
            throw new ApiException("Incorrect username/email or password.");
        }
        return user;
    }

    public User findByUsernameOrEmail(String usernameOrEmail) {
        if (usernameOrEmail == null) return null;
        String key = usernameOrEmail.trim().toLowerCase();

        User user = usersByUsername.get(key);
        if (user != null) return user;

        String username = usernameByEmail.get(key);
        return username == null ? null : usersByUsername.get(username);
    }

    public User findByUsername(String username) {
        if (username == null) return null;
        return usersByUsername.get(username.trim().toLowerCase());
    }

    public User findById(String userId) {
        if (userId == null) return null;
        String username = usernameByUserId.get(userId);
        return username == null ? null : usersByUsername.get(username);
    }

    public void markEmailVerified(String email) {
        String normalizedEmail = email.trim().toLowerCase();
        String username = usernameByEmail.get(normalizedEmail);
        if (username != null) {
            User user = usersByUsername.get(username);
            if (user != null) user.setEmailVerified(true);
        }
    }

    public boolean isEmailAlreadyRegistered(String email) {
        return email != null && usernameByEmail.containsKey(email.trim().toLowerCase());
    }
}
