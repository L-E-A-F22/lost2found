package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.util.IdUtil;

import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Tracks active login sessions.
 *
 * Data structure: ConcurrentHashMap<token, Session> - O(1) lookup,
 * thread-safe for the multi-threaded HTTP server.
 */
public class AuthService {

    private static final long SESSION_TTL_SECONDS = 60L * 60 * 24 * 14; // 14 days

    private static class Session {
        final String userId;
        final Instant expiresAt;
        Session(String userId) {
            this.userId = userId;
            this.expiresAt = Instant.now().plusSeconds(SESSION_TTL_SECONDS);
        }
    }

    private final Map<String, Session> sessions = new ConcurrentHashMap<>();

    public String createSession(String userId) {
        String token = IdUtil.newToken();
        sessions.put(token, new Session(userId));
        return token;
    }

    /**
     * Resolves a token to a userId, or throws. The message deliberately
     * contains "sign in" so the frontend's existing regex
     * (/session|sign in/i) auto-triggers a clean sign-out.
     */
    public String requireUserId(String token) throws ApiException {
        if (token == null || token.isEmpty()) {
            throw new ApiException("Your session has expired. Please sign in again.");
        }
        Session session = sessions.get(token);
        if (session == null) {
            throw new ApiException("Your session has expired. Please sign in again.");
        }
        if (Instant.now().isAfter(session.expiresAt)) {
            sessions.remove(token);
            throw new ApiException("Your session has expired. Please sign in again.");
        }
        return session.userId;
    }

    public void invalidate(String token) {
        if (token != null) sessions.remove(token);
    }
}
