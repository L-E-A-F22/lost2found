package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.OtpChallenge;
import com.lost2found.util.EmailUtil;
import com.lost2found.util.IdUtil;

import java.io.IOException;
import java.time.Instant;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Handles the "confirm your email works" flow used during registration:
 *   1. sendEmailOtp(email)      -> generates + emails a 6-digit code
 *   2. verify(email, code)      -> checks it, then issues a short-lived
 *                                   verifyToken proving that email was
 *                                   confirmed, WITHOUT creating an
 *                                   account yet
 *   3. register(...) elsewhere  -> requires that verifyToken to match
 *                                   the email being registered
 *
 * Data structures:
 *  - ConcurrentHashMap<email, OtpChallenge>   one live code per email
 *  - ConcurrentHashMap<verifyToken, VerifiedEmail>  proof of a recent
 *    successful OTP check, consumed by register()
 */
public class OtpService {

    private static final long VERIFY_TOKEN_TTL_SECONDS = 60L * 15; // 15 minutes

    private static class VerifiedEmail {
        final String email;
        final Instant expiresAt;
        VerifiedEmail(String email) {
            this.email = email;
            this.expiresAt = Instant.now().plusSeconds(VERIFY_TOKEN_TTL_SECONDS);
        }
    }

    private final Map<String, OtpChallenge> activeOtps = new ConcurrentHashMap<>();
    private final Map<String, VerifiedEmail> verifiedEmails = new ConcurrentHashMap<>();
    private final EmailUtil.SmtpConfig smtpConfig;

    public OtpService(EmailUtil.SmtpConfig smtpConfig) {
        this.smtpConfig = smtpConfig;
    }

    public void issueAndSend(String email) throws ApiException {
        String normalized = normalize(email);
        String code = IdUtil.newSixDigitOtp();
        activeOtps.put(normalized, new OtpChallenge(code));

        try {
            EmailUtil.sendOtpEmail(smtpConfig, email, code);
        } catch (IOException e) {
            activeOtps.remove(normalized);
            throw new ApiException("Could not send the verification email. Please try again shortly.");
        }
    }

    /** Returns a verifyToken to hand back to the frontend on success. */
    public String verify(String email, String submittedCode) throws ApiException {
        String key = normalize(email);
        OtpChallenge challenge = activeOtps.get(key);

        if (challenge == null) {
            throw new ApiException("Send a code to this email first.");
        }
        if (challenge.isExpired()) {
            activeOtps.remove(key);
            throw new ApiException("This code has expired. Send a new one.");
        }
        if (challenge.attemptsExceeded()) {
            activeOtps.remove(key);
            throw new ApiException("Too many incorrect attempts. Send a new code.");
        }

        challenge.registerAttempt();

        if (submittedCode == null || !constantTimeEquals(challenge.getCode(), submittedCode.trim())) {
            throw new ApiException("That code is not right.");
        }

        activeOtps.remove(key);

        String verifyToken = IdUtil.newToken();
        verifiedEmails.put(verifyToken, new VerifiedEmail(key));
        return verifyToken;
    }

    /**
     * Consumes a verifyToken - checks it's valid, unexpired, and was
     * issued for exactly this email. Called once, from register().
     */
    public void consumeVerifyToken(String verifyToken, String email) throws ApiException {
        if (verifyToken == null) {
            throw new ApiException("Confirm your email with the code before creating the account.");
        }
        VerifiedEmail v = verifiedEmails.get(verifyToken);
        if (v == null || Instant.now().isAfter(v.expiresAt)) {
            verifiedEmails.remove(verifyToken);
            throw new ApiException("Your email confirmation expired. Send and confirm the code again.");
        }
        if (!v.email.equals(normalize(email))) {
            throw new ApiException("That confirmation code does not match this email.");
        }
        verifiedEmails.remove(verifyToken);
    }

    private String normalize(String email) {
        return email == null ? "" : email.trim().toLowerCase();
    }

    private boolean constantTimeEquals(String a, String b) {
        if (a == null || b == null) return false;
        if (a.length() != b.length()) return false;
        int result = 0;
        for (int i = 0; i < a.length(); i++) {
            result |= a.charAt(i) ^ b.charAt(i);
        }
        return result == 0;
    }
}
