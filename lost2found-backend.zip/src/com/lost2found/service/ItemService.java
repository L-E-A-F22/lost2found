package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.Item;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Stores and searches item listings.
 *
 * Data structure: ConcurrentHashMap<itemId, Item> - the item list
 * views (home feed, search, "mine") are all built by filtering/
 * sorting a snapshot of this map's values, which is cheap at
 * campus-app scale and keeps the storage layer trivially simple.
 */
public class ItemService {

    private final Map<String, Item> items = new ConcurrentHashMap<>();

    public Item create(String ownerUserId, String type, String name, String brand, String category,
                        String color, String dateOn, String place, String description, double reward,
                        String photoFull, String photoThumb) throws ApiException {

        if (name == null || name.trim().isEmpty()) throw new ApiException("Give the item a name.");
        if (!"lost".equals(type) && !"found".equals(type)) throw new ApiException("Say whether this was lost or found.");
        if (place == null || place.trim().isEmpty()) throw new ApiException("Say where this happened on campus.");

        Item item = new Item(ownerUserId, type, name.trim(), brand, category, color, dateOn,
                place.trim(), description, Math.max(0, reward));
        if (photoFull != null && !photoFull.isEmpty()) {
            item.setPhoto(photoFull, photoThumb);
        }
        items.put(item.getItemId(), item);
        return item;
    }

    public Item get(String itemId) throws ApiException {
        Item item = items.get(itemId);
        if (item == null) throw new ApiException("That listing no longer exists.");
        return item;
    }

    public void requireOwner(Item item, String userId) throws ApiException {
        if (!item.getOwnerUserId().equals(userId)) {
            throw new ApiException("Only the person who posted this can do that.");
        }
    }

    public void setStatus(Item item, String status) throws ApiException {
        if (!Item.STATUS_OPEN.equals(status) && !Item.STATUS_MATCHED.equals(status)
                && !Item.STATUS_RETURNED.equals(status)) {
            throw new ApiException("Unknown status.");
        }
        item.setStatus(status);
    }

    public void delete(String itemId) {
        items.remove(itemId);
    }

    /**
     * scope: null/"all" -> everyone's items; "mine" -> only this user's.
     * status: "all" -> any status; otherwise an exact match.
     */
    public List<Item> search(String query, String type, String category, String status,
                              String scope, String currentUserId, int limit) {
        String q = query == null ? "" : query.trim().toLowerCase();

        List<Item> result = new ArrayList<>();
        for (Item item : items.values()) {
            if ("mine".equals(scope) && !item.getOwnerUserId().equals(currentUserId)) continue;
            if (type != null && !type.isEmpty() && !"all".equals(type) && !type.equals(item.getType())) continue;
            if (category != null && !category.isEmpty() && !"all".equals(category)
                    && !category.equalsIgnoreCase(item.getCategory())) continue;
            if (status != null && !status.isEmpty() && !"all".equals(status) && !status.equals(item.getStatus())) continue;

            if (!q.isEmpty()) {
                boolean matches = containsIgnoreCase(item.getName(), q)
                        || containsIgnoreCase(item.getCode(), q)
                        || containsIgnoreCase(item.getCategory(), q);
                if (!matches) continue;
            }
            result.add(item);
        }

        result.sort(Comparator.comparing(Item::getCreatedAt).reversed());

        if (limit > 0 && result.size() > limit) {
            return result.subList(0, limit);
        }
        return result;
    }

    public int countByStatus(String status) {
        int n = 0;
        for (Item item : items.values()) {
            if (status.equals(item.getStatus())) n++;
        }
        return n;
    }

    public int countByTypeAndStatus(String type, String status) {
        int n = 0;
        for (Item item : items.values()) {
            if (type.equals(item.getType()) && status.equals(item.getStatus())) n++;
        }
        return n;
    }

    public int countByOwner(String userId) {
        int n = 0;
        for (Item item : items.values()) {
            if (item.getOwnerUserId().equals(userId)) n++;
        }
        return n;
    }

    private boolean containsIgnoreCase(String haystack, String needleLower) {
        return haystack != null && haystack.toLowerCase().contains(needleLower);
    }
}
