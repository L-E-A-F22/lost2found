package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.Claim;
import com.lost2found.model.Item;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Data structure: ConcurrentHashMap<claimId, Claim>, plus queries
 * filtered by itemId / fromUserId built by scanning values() - fine
 * at this scale, keeps the storage layer dependency-free.
 */
public class ClaimService {

    private final Map<String, Claim> claims = new ConcurrentHashMap<>();

    public Claim create(Item item, String fromUserId, String proof) throws ApiException {
        if (item.getOwnerUserId().equals(fromUserId)) {
            throw new ApiException("You cannot claim your own listing.");
        }
        if (proof == null || proof.trim().isEmpty()) {
            throw new ApiException("Describe a detail that proves this is yours.");
        }
        Claim claim = new Claim(item.getItemId(), fromUserId, proof.trim());
        claims.put(claim.getClaimId(), claim);
        return claim;
    }

    public Claim get(String claimId) throws ApiException {
        Claim claim = claims.get(claimId);
        if (claim == null) throw new ApiException("That claim no longer exists.");
        return claim;
    }

    public void resolve(Claim claim, String status) throws ApiException {
        if (!Claim.STATUS_ACCEPTED.equals(status) && !Claim.STATUS_DECLINED.equals(status)) {
            throw new ApiException("Unknown decision.");
        }
        claim.setStatus(status);
    }

    public List<Claim> forItem(String itemId) {
        List<Claim> result = new ArrayList<>();
        for (Claim c : claims.values()) {
            if (c.getItemId().equals(itemId)) result.add(c);
        }
        result.sort(Comparator.comparing(Claim::getCreatedAt));
        return result;
    }

    public List<Claim> byClaimant(String userId) {
        List<Claim> result = new ArrayList<>();
        for (Claim c : claims.values()) {
            if (c.getFromUserId().equals(userId)) result.add(c);
        }
        return result;
    }

    public List<Claim> all() {
        return new ArrayList<>(claims.values());
    }
}
