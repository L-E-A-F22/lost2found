package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.ChatMessage;
import com.lost2found.model.ChatThread;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Data structures:
 *  - ConcurrentHashMap<threadId, ChatThread>
 *  - ConcurrentHashMap<threadId, List<ChatMessage>>  messages per thread
 */
public class MessageService {

    private final Map<String, ChatThread> threads = new ConcurrentHashMap<>();
    private final Map<String, List<ChatMessage>> messagesByThread = new ConcurrentHashMap<>();

    /** Finds the existing thread between these two users, or creates one. */
    public ChatThread findOrCreateThread(String userAId, String userBId) throws ApiException {
        if (userAId.equals(userBId)) {
            throw new ApiException("You cannot message yourself.");
        }
        for (ChatThread t : threads.values()) {
            if (t.hasParticipant(userAId) && t.hasParticipant(userBId)) {
                return t;
            }
        }
        ChatThread thread = new ChatThread(userAId, userBId);
        threads.put(thread.getThreadId(), thread);
        messagesByThread.put(thread.getThreadId(), new ArrayList<>());
        return thread;
    }

    public ChatThread getThread(String threadId) throws ApiException {
        ChatThread thread = threads.get(threadId);
        if (thread == null) throw new ApiException("That conversation no longer exists.");
        return thread;
    }

    public void requireParticipant(ChatThread thread, String userId) throws ApiException {
        if (!thread.hasParticipant(userId)) {
            throw new ApiException("That conversation isn't yours to open.");
        }
    }

    public ChatMessage send(ChatThread thread, String fromUserId, String body) throws ApiException {
        if (body == null || body.trim().isEmpty()) {
            throw new ApiException("Write a message first.");
        }
        ChatMessage message = new ChatMessage(thread.getThreadId(), fromUserId, body.trim());
        messagesByThread.computeIfAbsent(thread.getThreadId(), k -> new ArrayList<>()).add(message);
        return message;
    }

    public List<ChatMessage> messagesIn(String threadId) {
        return messagesByThread.getOrDefault(threadId, new ArrayList<>());
    }

    public List<ChatThread> threadsFor(String userId) {
        List<ChatThread> result = new ArrayList<>();
        for (ChatThread t : threads.values()) {
            if (t.hasParticipant(userId)) result.add(t);
        }
        result.sort(Comparator.comparing((ChatThread t) -> lastActivity(t.getThreadId())).reversed());
        return result;
    }

    private java.time.Instant lastActivity(String threadId) {
        List<ChatMessage> msgs = messagesByThread.getOrDefault(threadId, new ArrayList<>());
        if (msgs.isEmpty()) return java.time.Instant.EPOCH;
        return msgs.get(msgs.size() - 1).getCreatedAt();
    }

    public ChatMessage lastMessage(String threadId) {
        List<ChatMessage> msgs = messagesByThread.getOrDefault(threadId, new ArrayList<>());
        return msgs.isEmpty() ? null : msgs.get(msgs.size() - 1);
    }
}
