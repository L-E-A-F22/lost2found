package com.lost2found.service;

import com.lost2found.exception.ApiException;
import com.lost2found.model.Issue;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

/** Data structure: CopyOnWriteArrayList - simple append-mostly log, thread-safe for occasional writes. */
public class IssueService {

    private final List<Issue> issues = new CopyOnWriteArrayList<>();

    public Issue report(String fromUserId, String subject, String body) throws ApiException {
        if (subject == null || subject.trim().isEmpty()) {
            throw new ApiException("Give it a short summary.");
        }
        Issue issue = new Issue(fromUserId, subject.trim(), body == null ? "" : body.trim());
        issues.add(issue);
        return issue;
    }

    public List<Issue> all() {
        return issues;
    }
}
