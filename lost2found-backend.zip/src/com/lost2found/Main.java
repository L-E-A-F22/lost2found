package com.lost2found;

import com.lost2found.rpc.RpcAction;
import com.lost2found.rpc.RpcActions;
import com.lost2found.rpc.RpcDispatcher;
import com.lost2found.service.AuthService;
import com.lost2found.service.ClaimService;
import com.lost2found.service.IssueService;
import com.lost2found.service.ItemService;
import com.lost2found.service.MessageService;
import com.lost2found.service.OtpService;
import com.lost2found.service.UserService;
import com.lost2found.util.EmailUtil;
import com.sun.net.httpserver.HttpServer;

import java.io.IOException;
import java.net.InetSocketAddress;
import java.util.Map;
import java.util.concurrent.Executors;

/**
 * Lost2Found backend entry point.
 *
 * Run with:  java -cp out com.lost2found.Main
 * (see README.md for the compile step)
 *
 * ============================================================
 *  BEFORE RUNNING FOR REAL: fill in your Gmail SMTP credentials
 *  below, or OTP emails will fail to send.
 * ============================================================
 */
public class Main {

    private static final int PORT = 8080;

    // ---- SMTP / EMAIL OTP CONFIGURATION ----------------------------
    // Gmail: host=smtp.gmail.com, port=465
    // username = your full Gmail address
    // password = a 16-character "App Password" from
    //            https://myaccount.google.com/apppasswords
    //            (requires 2-Step Verification enabled first -
    //            do NOT use your normal Gmail password here)
    private static final String SMTP_HOST = "smtp.gmail.com";
    private static final int SMTP_PORT = 465;
    private static final String SMTP_USERNAME = "YOUR_GMAIL_ADDRESS@gmail.com";
    private static final String SMTP_PASSWORD = "YOUR_16_CHAR_APP_PASSWORD";
    // ------------------------------------------------------------------

    public static void main(String[] args) {
        try {
            EmailUtil.SmtpConfig smtpConfig =
                    new EmailUtil.SmtpConfig(SMTP_HOST, SMTP_PORT, SMTP_USERNAME, SMTP_PASSWORD);

            UserService userService = new UserService();
            AuthService authService = new AuthService();
            OtpService otpService = new OtpService(smtpConfig);
            ItemService itemService = new ItemService();
            ClaimService claimService = new ClaimService();
            MessageService messageService = new MessageService();
            IssueService issueService = new IssueService();

            Map<String, RpcAction> registry = RpcActions.buildRegistry(
                    userService, authService, otpService, itemService,
                    claimService, messageService, issueService);

            HttpServer server = HttpServer.create(new InetSocketAddress(PORT), 0);
            server.createContext("/", new RpcDispatcher(registry, authService));
            server.setExecutor(Executors.newFixedThreadPool(16));
            server.start();

            System.out.println("Lost2Found backend running at http://localhost:" + PORT);
            System.out.println("Single RPC endpoint: POST http://localhost:" + PORT + "/");
            System.out.println("Actions available: " + registry.keySet());

            if (SMTP_USERNAME.startsWith("YOUR_")) {
                System.out.println();
                System.out.println("WARNING: SMTP credentials in Main.java are still placeholders.");
                System.out.println("OTP emails will fail until you set SMTP_USERNAME / SMTP_PASSWORD.");
            }

        } catch (IOException e) {
            System.err.println("Failed to start server: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
