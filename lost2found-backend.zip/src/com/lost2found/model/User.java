package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class User {

    private final String userId;
    private final String username;      // the public handle - "@username" - unique, lowercase-checked
    private String displayName;
    private final String email;
    private final String phone;
    private final String passwordHash;
    private final String passwordSalt;
    private boolean emailVerified;
    private final Instant createdAt;

    public User(String username, String displayName, String email, String phone,
                String passwordHash, String passwordSalt) {
        this.userId = IdUtil.newInternalId();
        this.username = username;
        this.displayName = displayName;
        this.email = email;
        this.phone = phone;
        this.passwordHash = passwordHash;
        this.passwordSalt = passwordSalt;
        this.emailVerified = false;
        this.createdAt = Instant.now();
    }

    public String getUserId() { return userId; }
    public String getUsername() { return username; }
    public String getDisplayName() { return displayName; }
    public String getEmail() { return email; }
    public String getPhone() { return phone; }
    public String getPasswordHash() { return passwordHash; }
    public String getPasswordSalt() { return passwordSalt; }
    public boolean isEmailVerified() { return emailVerified; }
    public void setEmailVerified(boolean v) { this.emailVerified = v; }
    public Instant getCreatedAt() { return createdAt; }

    /** Public-facing view - what OTHER users are allowed to see. */
    public Map<String, Object> toPublicView() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("username", username);
        m.put("displayName", displayName);
        return m;
    }

    /** "me" view returned to the account owner right after login/register/session. */
    public Map<String, Object> toMeView() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("userId", userId);
        m.put("username", username);
        m.put("displayName", displayName);
        return m;
    }

    /** Full account view - only ever returned to the owner themself (Account page). */
    public Map<String, Object> toAccountView() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("displayName", displayName);
        m.put("username", username);
        m.put("email", email);
        m.put("phone", phone);
        m.put("createdAt", createdAt.toString());
        return m;
    }
}
