package com.lost2found.model;

import java.time.Instant;

public class OtpChallenge {

    public static final int VALIDITY_MINUTES = 10;
    public static final int MAX_ATTEMPTS = 5;

    private final String code;
    private final Instant expiresAt;
    private int attempts;

    public OtpChallenge(String code) {
        this.code = code;
        this.expiresAt = Instant.now().plusSeconds(VALIDITY_MINUTES * 60L);
        this.attempts = 0;
    }

    public String getCode() { return code; }
    public boolean isExpired() { return Instant.now().isAfter(expiresAt); }
    public boolean attemptsExceeded() { return attempts >= MAX_ATTEMPTS; }
    public void registerAttempt() { attempts++; }
}
