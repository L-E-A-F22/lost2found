package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class Item {

    public static final String STATUS_OPEN = "open";
    public static final String STATUS_MATCHED = "matched";
    public static final String STATUS_RETURNED = "returned";

    private final String itemId;
    private final String code;
    private final String ownerUserId;
    private final String type;        // "lost" | "found"
    private String name;
    private String brand;
    private String category;
    private String color;
    private String dateOn;
    private String place;
    private String description;
    private double reward;
    private String status;
    private String photoFull;         // data URL, nullable
    private String photoThumb;        // data URL, nullable
    private final Instant createdAt;

    public Item(String ownerUserId, String type, String name, String brand, String category,
                String color, String dateOn, String place, String description, double reward) {
        this.itemId = IdUtil.newInternalId();
        this.code = IdUtil.newItemCode();
        this.ownerUserId = ownerUserId;
        this.type = type;
        this.name = name;
        this.brand = brand;
        this.category = category;
        this.color = color;
        this.dateOn = dateOn;
        this.place = place;
        this.description = description;
        this.reward = reward;
        this.status = STATUS_OPEN;
        this.createdAt = Instant.now();
    }

    public String getItemId() { return itemId; }
    public String getCode() { return code; }
    public String getOwnerUserId() { return ownerUserId; }
    public String getType() { return type; }
    public String getName() { return name; }
    public String getCategory() { return category; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public double getReward() { return reward; }
    public Instant getCreatedAt() { return createdAt; }
    public boolean hasPhoto() { return photoFull != null && !photoFull.isEmpty(); }
    public String getPhotoFull() { return photoFull; }
    public String getPhotoThumb() { return photoThumb; }

    public void setPhoto(String full, String thumb) {
        this.photoFull = full;
        this.photoThumb = thumb;
    }

    /** Card / list view - matches itemCard(i) fields exactly. */
    public Map<String, Object> toCardView() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("itemId", itemId);
        m.put("code", code);
        m.put("type", type);
        m.put("status", status);
        m.put("name", name);
        m.put("brand", brand);
        m.put("category", category);
        m.put("place", place);
        m.put("dateOn", dateOn);
        m.put("reward", reward);
        m.put("thumb", photoThumb);
        return m;
    }

    /** Full detail view - matches openItem(itemId) usage. */
    public Map<String, Object> toDetailView(boolean mine, User owner) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("itemId", itemId);
        m.put("code", code);
        m.put("type", type);
        m.put("status", status);
        m.put("name", name);
        m.put("brand", brand);
        m.put("category", category);
        m.put("color", color);
        m.put("dateOn", dateOn);
        m.put("place", place);
        m.put("description", description);
        m.put("reward", reward);
        m.put("thumb", photoThumb);
        m.put("hasPhoto", hasPhoto());
        m.put("mine", mine);
        m.put("owner", owner == null ? null : owner.toPublicView());
        m.put("createdAt", createdAt.toString());
        return m;
    }
}
