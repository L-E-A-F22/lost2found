package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class Claim {

    public static final String STATUS_PENDING = "pending";
    public static final String STATUS_ACCEPTED = "accepted";
    public static final String STATUS_DECLINED = "declined";

    private final String claimId;
    private final String itemId;
    private final String fromUserId;
    private final String proof;
    private String status;
    private final Instant createdAt;

    public Claim(String itemId, String fromUserId, String proof) {
        this.claimId = IdUtil.newInternalId();
        this.itemId = itemId;
        this.fromUserId = fromUserId;
        this.proof = proof;
        this.status = STATUS_PENDING;
        this.createdAt = Instant.now();
    }

    public String getClaimId() { return claimId; }
    public String getItemId() { return itemId; }
    public String getFromUserId() { return fromUserId; }
    public String getProof() { return proof; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public Instant getCreatedAt() { return createdAt; }

    public Map<String, Object> toView(boolean mine, User from) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("claimId", claimId);
        m.put("itemId", itemId);
        m.put("status", status);
        m.put("proof", proof);
        m.put("mine", mine);
        m.put("from", from == null ? null : from.toPublicView());
        m.put("createdAt", createdAt.toString());
        return m;
    }
}
