package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;

public class Issue {
    private final String issueId;
    private final String fromUserId;
    private final String subject;
    private final String body;
    private final Instant createdAt;

    public Issue(String fromUserId, String subject, String body) {
        this.issueId = IdUtil.newInternalId();
        this.fromUserId = fromUserId;
        this.subject = subject;
        this.body = body;
        this.createdAt = Instant.now();
    }

    public String getIssueId() { return issueId; }
    public String getFromUserId() { return fromUserId; }
    public String getSubject() { return subject; }
    public String getBody() { return body; }
    public Instant getCreatedAt() { return createdAt; }
}
