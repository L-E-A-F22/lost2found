package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.Map;

public class ChatMessage {

    private final String messageId;
    private final String threadId;
    private final String fromUserId;
    private final String body;
    private final Instant createdAt;

    public ChatMessage(String threadId, String fromUserId, String body) {
        this.messageId = IdUtil.newInternalId();
        this.threadId = threadId;
        this.fromUserId = fromUserId;
        this.body = body;
        this.createdAt = Instant.now();
    }

    public String getMessageId() { return messageId; }
    public String getThreadId() { return threadId; }
    public String getFromUserId() { return fromUserId; }
    public String getBody() { return body; }
    public Instant getCreatedAt() { return createdAt; }

    public Map<String, Object> toView(boolean mine) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("messageId", messageId);
        m.put("body", body);
        m.put("mine", mine);
        m.put("createdAt", createdAt.toString());
        return m;
    }
}
