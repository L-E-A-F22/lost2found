package com.lost2found.model;

import com.lost2found.util.IdUtil;

import java.time.Instant;

public class ChatThread {

    private final String threadId;
    private final String userAId;
    private final String userBId;
    private final Instant createdAt;

    public ChatThread(String userAId, String userBId) {
        this.threadId = IdUtil.newInternalId();
        this.userAId = userAId;
        this.userBId = userBId;
        this.createdAt = Instant.now();
    }

    public String getThreadId() { return threadId; }
    public String getUserAId() { return userAId; }
    public String getUserBId() { return userBId; }
    public Instant getCreatedAt() { return createdAt; }

    public boolean hasParticipant(String userId) {
        return userAId.equals(userId) || userBId.equals(userId);
    }

    public String otherParticipant(String userId) {
        return userAId.equals(userId) ? userBId : userAId;
    }
}
