package com.lost2found.rpc;

import com.lost2found.exception.ApiException;
import com.lost2found.service.AuthService;
import com.lost2found.util.JsonUtil;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpHandler;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * Mirrors the single-endpoint RPC contract the frontend already
 * speaks: POST body {"action": "...", "payload": {...}, "token": "..."}
 * always answered with HTTP 200 and a JSON envelope of either
 * {"ok":true,"data":{...}} or {"ok":false,"error":"..."} - exactly
 * what the existing settleRpc() in index.html expects, so nothing in
 * the UI layer has to change shape.
 */
public class RpcDispatcher implements HttpHandler {

    private static final Set<String> PUBLIC_ACTIONS = new HashSet<>(java.util.Arrays.asList(
            "checkUsername", "sendEmailOtp", "verifyEmailOtp", "register", "login"
    ));

    private final Map<String, RpcAction> registry;
    private final AuthService authService;

    public RpcDispatcher(Map<String, RpcAction> registry, AuthService authService) {
        this.registry = registry;
        this.authService = authService;
    }

    @Override
    public void handle(HttpExchange exchange) throws IOException {
        addCorsHeaders(exchange);

        if ("OPTIONS".equalsIgnoreCase(exchange.getRequestMethod())) {
            exchange.sendResponseHeaders(204, -1);
            return;
        }

        if (!"POST".equalsIgnoreCase(exchange.getRequestMethod())) {
            respond(exchange, errorEnvelope("This endpoint only accepts POST."));
            return;
        }

        Map<String, Object> root;
        try {
            String body = readBody(exchange);
            root = JsonUtil.parseObject(body);
        } catch (Exception e) {
            respond(exchange, errorEnvelope("Could not read the request."));
            return;
        }

        String action = JsonUtil.str(root, "action");
        Map<String, Object> payload = JsonUtil.obj(root, "payload");
        String token = JsonUtil.str(root, "token");

        if (action == null || !registry.containsKey(action)) {
            respond(exchange, errorEnvelope("Unknown action: " + action));
            return;
        }

        try {
            String userId = null;
            if (!PUBLIC_ACTIONS.contains(action)) {
                userId = authService.requireUserId(token);
            }
            Map<String, Object> data = registry.get(action).handle(userId, payload);
            respond(exchange, successEnvelope(data));

        } catch (ApiException e) {
            respond(exchange, errorEnvelope(e.getMessage()));
        } catch (Exception e) {
            // Catch-all: never let a bug leak a stack trace to the
            // client or crash the handler thread.
            respond(exchange, errorEnvelope("Something went wrong. Please try again."));
        }
    }

    private Map<String, Object> successEnvelope(Map<String, Object> data) {
        Map<String, Object> envelope = new LinkedHashMap<>();
        envelope.put("ok", true);
        envelope.put("data", data);
        return envelope;
    }

    private Map<String, Object> errorEnvelope(String message) {
        Map<String, Object> envelope = new LinkedHashMap<>();
        envelope.put("ok", false);
        envelope.put("error", message);
        return envelope;
    }

    private void respond(HttpExchange exchange, Map<String, Object> envelope) throws IOException {
        String json = JsonUtil.stringify(envelope);
        byte[] bytes = json.getBytes(StandardCharsets.UTF_8);
        exchange.getResponseHeaders().set("Content-Type", "application/json; charset=UTF-8");
        exchange.sendResponseHeaders(200, bytes.length);
        try (OutputStream os = exchange.getResponseBody()) {
            os.write(bytes);
        }
    }

    private void addCorsHeaders(HttpExchange exchange) {
        exchange.getResponseHeaders().set("Access-Control-Allow-Origin", "*");
        exchange.getResponseHeaders().set("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        exchange.getResponseHeaders().set("Access-Control-Allow-Headers", "Content-Type, Authorization");
    }

    private String readBody(HttpExchange exchange) throws IOException {
        InputStream is = exchange.getRequestBody();
        ByteArrayOutputStream buffer = new ByteArrayOutputStream();
        byte[] chunk = new byte[2048];
        int bytesRead;
        while ((bytesRead = is.read(chunk)) != -1) {
            buffer.write(chunk, 0, bytesRead);
        }
        return buffer.toString("UTF-8");
    }
}
