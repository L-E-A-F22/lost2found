package com.lost2found.rpc;

import com.lost2found.exception.ApiException;
import com.lost2found.model.ChatMessage;
import com.lost2found.model.ChatThread;
import com.lost2found.model.Claim;
import com.lost2found.model.Item;
import com.lost2found.model.User;
import com.lost2found.service.AuthService;
import com.lost2found.service.ClaimService;
import com.lost2found.service.IssueService;
import com.lost2found.service.ItemService;
import com.lost2found.service.MessageService;
import com.lost2found.service.OtpService;
import com.lost2found.service.UserService;
import com.lost2found.util.IdUtil;
import com.lost2found.util.JsonUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Builds the full action registry: one RpcAction per frontend call
 * (register, login, createItem, sendMessage, ...). This is the layer
 * that turns raw JSON payloads into service calls and service results
 * back into the exact JSON shapes index.html already expects.
 */
public final class RpcActions {

    private RpcActions() {
    }

    public static Map<String, RpcAction> buildRegistry(
            UserService userService,
            AuthService authService,
            OtpService otpService,
            ItemService itemService,
            ClaimService claimService,
            MessageService messageService,
            IssueService issueService) {

        Map<String, RpcAction> r = new LinkedHashMap<>();

        // ---------------------------------------------------------
        // AUTH
        // ---------------------------------------------------------

        r.put("checkUsername", (userId, payload) -> {
            String username = JsonUtil.str(payload, "username");
            String reason = userService.usernameUnavailableReason(username);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("available", reason == null);
            if (reason != null) data.put("reason", reason);
            return data;
        });

        r.put("sendEmailOtp", (userId, payload) -> {
            String email = JsonUtil.str(payload, "email");
            if (email == null || !email.contains("@")) {
                throw new ApiException("Enter a valid email address.");
            }
            otpService.issueAndSend(email);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("maskedEmail", IdUtil.maskEmail(email));
            data.put("ttlMinutes", 10);
            return data;
        });

        r.put("verifyEmailOtp", (userId, payload) -> {
            String email = JsonUtil.str(payload, "email");
            String code = JsonUtil.str(payload, "code");
            String verifyToken = otpService.verify(email, code);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("verifyToken", verifyToken);
            return data;
        });

        r.put("register", (userId, payload) -> {
            String displayName = JsonUtil.str(payload, "displayName");
            String username = JsonUtil.str(payload, "username");
            String email = JsonUtil.str(payload, "email");
            String phone = JsonUtil.str(payload, "phone");
            String password = JsonUtil.str(payload, "password");
            String confirm = JsonUtil.str(payload, "confirm");
            String verifyToken = JsonUtil.str(payload, "verifyToken");

            otpService.consumeVerifyToken(verifyToken, email);
            User user = userService.register(displayName, username, email, phone, password, confirm);
            user.setEmailVerified(true);

            String token = authService.createSession(user.getUserId());
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("token", token);
            data.put("me", user.toMeView());
            return data;
        });

        r.put("login", (userId, payload) -> {
            String usernameOrEmail = JsonUtil.str(payload, "username", JsonUtil.str(payload, "usernameOrEmail"));
            String password = JsonUtil.str(payload, "password");
            User user = userService.login(usernameOrEmail, password);
            String token = authService.createSession(user.getUserId());
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("token", token);
            data.put("me", user.toMeView());
            return data;
        });

        r.put("logout", (userId, payload) -> new LinkedHashMap<>());

        r.put("session", (userId, payload) -> {
            User user = requireSelf(userService, userId);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("me", user.toMeView());
            return data;
        });

        // ---------------------------------------------------------
        // ITEMS
        // ---------------------------------------------------------

        r.put("createItem", (userId, payload) -> {
            Map<String, Object> itemPayload = JsonUtil.obj(payload, "item");
            Map<String, Object> photoPayload = JsonUtil.obj(payload, "photo");

            Item item = itemService.create(
                    userId,
                    JsonUtil.str(itemPayload, "type"),
                    JsonUtil.str(itemPayload, "name"),
                    JsonUtil.str(itemPayload, "brand"),
                    JsonUtil.str(itemPayload, "category"),
                    JsonUtil.str(itemPayload, "color"),
                    JsonUtil.str(itemPayload, "dateOn"),
                    JsonUtil.str(itemPayload, "place"),
                    JsonUtil.str(itemPayload, "description"),
                    JsonUtil.num(itemPayload, "reward", 0),
                    JsonUtil.str(photoPayload, "full"),
                    JsonUtil.str(photoPayload, "thumb")
            );

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("item", item.toCardView());
            return data;
        });

        r.put("listItems", (userId, payload) -> {
            String q = JsonUtil.str(payload, "q");
            String type = JsonUtil.str(payload, "type");
            String category = JsonUtil.str(payload, "category");
            String status = JsonUtil.str(payload, "status", "open");
            String scope = JsonUtil.str(payload, "scope");
            int limit = (int) JsonUtil.num(payload, "limit", 60);

            List<Item> found = itemService.search(q, type, category, status, scope, userId, limit);
            List<Object> cards = new ArrayList<>();
            for (Item item : found) cards.add(item.toCardView());

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("items", cards);
            data.put("total", cards.size());
            return data;
        });

        r.put("getItem", (userId, payload) -> {
            String itemId = JsonUtil.str(payload, "itemId");
            Item item = itemService.get(itemId);
            boolean mine = item.getOwnerUserId().equals(userId);
            User owner = userService.findById(item.getOwnerUserId());

            Map<String, Object> itemView = item.toDetailView(mine, owner);

            List<Object> claimViews = new ArrayList<>();
            for (Claim c : claimService.forItem(itemId)) {
                boolean claimMine = c.getFromUserId().equals(userId);
                if (mine || claimMine) {
                    User from = userService.findById(c.getFromUserId());
                    claimViews.add(c.toView(claimMine, from));
                }
            }
            itemView.put("claims", claimViews);

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("item", itemView);
            return data;
        });

        r.put("getPhoto", (userId, payload) -> {
            String itemId = JsonUtil.str(payload, "itemId");
            Item item = itemService.get(itemId);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("dataUrl", item.getPhotoFull());
            return data;
        });

        r.put("setItemStatus", (userId, payload) -> {
            String itemId = JsonUtil.str(payload, "itemId");
            String status = JsonUtil.str(payload, "status");
            Item item = itemService.get(itemId);
            itemService.requireOwner(item, userId);
            itemService.setStatus(item, status);
            return new LinkedHashMap<>();
        });

        r.put("deleteItem", (userId, payload) -> {
            String itemId = JsonUtil.str(payload, "itemId");
            Item item = itemService.get(itemId);
            itemService.requireOwner(item, userId);
            itemService.delete(itemId);
            return new LinkedHashMap<>();
        });

        // ---------------------------------------------------------
        // CLAIMS
        // ---------------------------------------------------------

        r.put("createClaim", (userId, payload) -> {
            String itemId = JsonUtil.str(payload, "itemId");
            String proof = JsonUtil.str(payload, "proof");
            Item item = itemService.get(itemId);
            Claim claim = claimService.create(item, userId, proof);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("claim", claim.toView(true, userService.findById(userId)));
            return data;
        });

        r.put("listClaims", (userId, payload) -> {
            List<Object> claimRows = new ArrayList<>();
            for (Claim c : claimService.all()) {
                Item item;
                try {
                    item = itemService.get(c.getItemId());
                } catch (ApiException e) {
                    item = null;
                }
                boolean isOwner = item != null && item.getOwnerUserId().equals(userId);
                boolean isClaimant = c.getFromUserId().equals(userId);
                if (!isOwner && !isClaimant) continue;

                Map<String, Object> row = new LinkedHashMap<>();
                row.put("claimId", c.getClaimId());
                row.put("status", c.getStatus());
                row.put("proof", c.getProof());
                row.put("direction", isOwner ? "incoming" : "outgoing");
                row.put("createdAt", c.getCreatedAt().toString());
                row.put("item", item == null ? null : itemSnippet(item));

                String counterpartId = isOwner ? c.getFromUserId() : (item == null ? null : item.getOwnerUserId());
                User counterpart = counterpartId == null ? null : userService.findById(counterpartId);
                row.put("counterpart", counterpart == null ? null : counterpart.toPublicView());

                claimRows.add(row);
            }
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("claims", claimRows);
            return data;
        });

        r.put("resolveClaim", (userId, payload) -> {
            String claimId = JsonUtil.str(payload, "claimId");
            String status = JsonUtil.str(payload, "status");
            Claim claim = claimService.get(claimId);
            Item item = itemService.get(claim.getItemId());
            itemService.requireOwner(item, userId);
            claimService.resolve(claim, status);
            return new LinkedHashMap<>();
        });

        // ---------------------------------------------------------
        // MESSAGES
        // ---------------------------------------------------------

        r.put("startThread", (userId, payload) -> {
            String username = JsonUtil.str(payload, "username");
            User other = userService.findByUsername(username == null ? null : username.replaceFirst("^@", ""));
            if (other == null) throw new ApiException("No student uses that username.");
            ChatThread thread = messageService.findOrCreateThread(userId, other.getUserId());
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("threadId", thread.getThreadId());
            return data;
        });

        r.put("listThreads", (userId, payload) -> {
            List<Object> rows = new ArrayList<>();
            for (ChatThread t : messageService.threadsFor(userId)) {
                User other = userService.findById(t.otherParticipant(userId));
                ChatMessage last = messageService.lastMessage(t.getThreadId());

                Map<String, Object> row = new LinkedHashMap<>();
                row.put("threadId", t.getThreadId());
                row.put("with", other == null ? null : other.toPublicView());
                row.put("preview", last == null ? null : last.getBody());
                row.put("lastFromMe", last != null && last.getFromUserId().equals(userId));
                rows.add(row);
            }
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("threads", rows);
            return data;
        });

        r.put("listMessages", (userId, payload) -> {
            String threadId = JsonUtil.str(payload, "threadId");
            ChatThread thread = messageService.getThread(threadId);
            messageService.requireParticipant(thread, userId);
            User other = userService.findById(thread.otherParticipant(userId));

            List<Object> rows = new ArrayList<>();
            for (ChatMessage m : messageService.messagesIn(threadId)) {
                rows.add(m.toView(m.getFromUserId().equals(userId)));
            }

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("with", other == null ? null : other.toPublicView());
            data.put("messages", rows);
            return data;
        });

        r.put("sendMessage", (userId, payload) -> {
            String threadId = JsonUtil.str(payload, "threadId");
            String body = JsonUtil.str(payload, "body");
            ChatThread thread = messageService.getThread(threadId);
            messageService.requireParticipant(thread, userId);
            ChatMessage message = messageService.send(thread, userId, body);

            Map<String, Object> data = new LinkedHashMap<>();
            data.put("message", message.toView(true));
            return data;
        });

        // ---------------------------------------------------------
        // MISC
        // ---------------------------------------------------------

        r.put("stats", (userId, payload) -> {
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("lost", itemService.countByTypeAndStatus("lost", Item.STATUS_OPEN));
            data.put("found", itemService.countByTypeAndStatus("found", Item.STATUS_OPEN));
            data.put("returned", itemService.countByStatus(Item.STATUS_RETURNED));
            data.put("mine", itemService.countByOwner(userId));
            return data;
        });

        r.put("myData", (userId, payload) -> {
            User user = requireSelf(userService, userId);
            Map<String, Object> data = new LinkedHashMap<>();
            data.put("account", user.toAccountView());

            Map<String, Object> counts = new LinkedHashMap<>();
            counts.put("items", itemService.countByOwner(userId));
            data.put("counts", counts);

            data.put("stored", Arrays.asList(
                    "Your name, username, email and phone number",
                    "A salted hash of your password - never the password itself",
                    "The listings, claims and messages tied to your account"
            ));
            data.put("sharedWithOthers", Arrays.asList(
                    "Your username and display name",
                    "Anything you post: item listings, descriptions and photos",
                    "Messages you send, visible only to the recipient"
            ));
            data.put("neverShared", Arrays.asList(
                    "Your email address",
                    "Your phone number",
                    "Your password, in any form"
            ));
            return data;
        });

        r.put("reportIssue", (userId, payload) -> {
            String subject = JsonUtil.str(payload, "subject");
            String body = JsonUtil.str(payload, "body");
            issueService.report(userId, subject, body);
            return new LinkedHashMap<>();
        });

        return r;
    }

    private static User requireSelf(UserService userService, String userId) throws ApiException {
        User user = userService.findById(userId);
        if (user == null) throw new ApiException("Your session has expired. Please sign in again.");
        return user;
    }

    private static Map<String, Object> itemSnippet(Item item) {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("itemId", item.getItemId());
        m.put("name", item.getName());
        m.put("code", item.getCode());
        return m;
    }
}
