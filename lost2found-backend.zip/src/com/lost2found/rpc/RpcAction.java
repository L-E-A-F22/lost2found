package com.lost2found.rpc;

import com.lost2found.exception.ApiException;

import java.util.Map;

/**
 * One implementation per action name the frontend's rpc(action, payload)
 * can call. userId is null for the handful of public (pre-login) actions
 * and always non-null otherwise - see RpcDispatcher.PUBLIC_ACTIONS.
 */
@FunctionalInterface
public interface RpcAction {
    Map<String, Object> handle(String userId, Map<String, Object> payload) throws ApiException;
}
