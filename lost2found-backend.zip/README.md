# Lost2Found backend (Java)

A dependency-free Java backend for the Lost2Found campus app. Talks to
your existing `Index.html` frontend over a single JSON RPC endpoint,
so nothing in the UI changed - only the broken Google Apps Script
connection was replaced.

No Maven, no Gradle, no jars to download - only the JDK. Email OTP is
sent with a hand-written SMTP client using Java's built-in
`javax.net.ssl`, and passwords are salted SHA-256 using
`java.security` - both ship with every JDK.

## 1. Requirements

- JDK 17 or newer (`java -version` / `javac -version` to check)
- A Gmail account with **2-Step Verification** turned on, so you can
  generate an **App Password** for sending OTP emails

## 2. Configure your email credentials

Open `src/com/lost2found/Main.java` and fill in these two lines:

```java
private static final String SMTP_USERNAME = "YOUR_GMAIL_ADDRESS@gmail.com";
private static final String SMTP_PASSWORD = "YOUR_16_CHAR_APP_PASSWORD";
```

To get an App Password:
1. Go to https://myaccount.google.com/apppasswords
2. (You'll need 2-Step Verification turned on first, if it isn't already)
3. Create a new app password, name it "Lost2Found", copy the 16-character code
4. Paste it as `SMTP_PASSWORD` above - **not** your normal Gmail password

Until you do this, the server still runs fine, but `sendEmailOtp` will
return a clean error instead of silently failing.

## 3. Compile

From the `lost2found/` folder:

```bash
javac -d out $(find src -name "*.java")
```

On Windows (PowerShell), since `find` isn't available:

```powershell
Get-ChildItem -Recurse -Filter *.java -Path src | ForEach-Object { $_.FullName } | Out-File sources.txt
javac -d out "@sources.txt"
```

## 4. Run

```bash
java -cp out com.lost2found.Main
```

You should see:

```
Lost2Found backend running at http://localhost:8080
Single RPC endpoint: POST http://localhost:8080/
Actions available: [checkUsername, sendEmailOtp, verifyEmailOtp, register, login, ...]
```

Leave this running in its own terminal while you use the site.

## 5. Point the frontend at it

Already done in the `Index.html` you were given - look for this near
the top of the `<script>` block:

```js
var API_URL = "http://localhost:8080/";
```

Open `Index.html` in a browser (or serve it however you like) and the
app will talk to your local Java server. If you deploy the backend
somewhere else later (a VM, Render, Railway, etc), just change this
one line to that server's address.

## 6. What's actually running

One HTTP endpoint (`POST /`) that reads a JSON body shaped like:

```json
{ "action": "login", "payload": { "username": "leonard", "password": "..." }, "token": null }
```

...and always answers with:

```json
{ "ok": true, "data": { ... } }
```

or

```json
{ "ok": false, "error": "Human-readable message" }
```

This matches exactly what `index.html`'s existing `rpc()` /
`settleRpc()` functions already expect, so the whole frontend works
unmodified against it.

### Project layout

```
src/com/lost2found/
  Main.java                 entry point - wires everything, starts the server
  model/                    User, Item, Claim, ChatThread, ChatMessage, OtpChallenge, Issue
  service/                  one service per concern - see below
  rpc/                      RpcAction (interface), RpcActions (the 23 handlers),
                             RpcDispatcher (the actual HttpHandler)
  exception/                ApiException - the one checked exception every
                             service throws on a user-facing failure
  util/                     JsonUtil (hand-written parser/writer),
                             PasswordUtil (salted SHA-256),
                             EmailUtil (raw SMTPS client), IdUtil
```

| Service | Responsible for |
|---|---|
| `UserService` | registration, login, username rules, lookups |
| `AuthService` | session tokens (opaque, 14-day expiry) |
| `OtpService` | 6-digit email codes, expiry, attempt limiting, the `verifyToken` handshake |
| `ItemService` | lost/found listings - create, search, status, delete |
| `ClaimService` | proof-of-ownership claims on an item |
| `MessageService` | private two-person threads and the messages inside them |
| `IssueService` | "Something broken?" reports from the Account page |

### Data storage

Everything is in-memory (`ConcurrentHashMap`/`ArrayList` inside each
service), so **data resets when you restart the server**. That's
fine for development. To persist data, the natural next step is
swapping each service's internal map for a real database (e.g. JDBC +
Postgres/MySQL/SQLite) - nothing outside those service classes would
need to change, since the rest of the app only calls their public
methods.

### Security notes

- Passwords: salted SHA-256 (`PasswordUtil`). Solid for a self-hosted
  project; for a real production system, prefer a slow hash like
  bcrypt/argon2 via a library.
- Sessions: random opaque tokens, 14-day expiry, invalidated on logout.
- Privacy: `User.toPublicView()` only ever exposes `username` +
  `displayName` to other users. Email and phone only ever appear in
  `toAccountView()`, returned solely to the account owner via `myData`.
- OTP: 6-digit code, 10-minute expiry, max 5 wrong attempts before
  you must request a new one.
